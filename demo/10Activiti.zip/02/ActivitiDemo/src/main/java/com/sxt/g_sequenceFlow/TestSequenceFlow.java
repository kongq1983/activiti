package com.sxt.g_sequenceFlow;

import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipInputStream;

import org.activiti.engine.HistoryService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.ProcessEngines;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.history.HistoricTaskInstance;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.runtime.ProcessInstanceQuery;
import org.activiti.engine.task.Task;
import org.junit.jupiter.api.Test;

/**
 * 连线
 * 
 * @author LJH
 *
 */
public class TestSequenceFlow {

	private ProcessEngine processEngine = ProcessEngines.getDefaultProcessEngine();

	/**
	 * 部署流程使用zip
	 */
	@Test
	public void deployProcess() {
		// 得到流程部署的service
		RepositoryService repositoryService = this.processEngine.getRepositoryService();
		InputStream inputStream=this.getClass().getResourceAsStream("SequenceFlowBPMN.zip");
		ZipInputStream zipInputStream=new ZipInputStream(inputStream);
		Deployment deploy = repositoryService.createDeployment().name("报销流程")
				.addZipInputStream(zipInputStream).deploy();
		System.out.println("部署成功:流程部署ID：" + deploy.getId());
	}

	/**
	 * 启动流程
	 */
	@Test
	public void startProcess() {
		RuntimeService runtimeService = this.processEngine.getRuntimeService();
		String processDefinitionKey = "SequenceFlowBPMN";
		ProcessInstance processInstance = runtimeService.startProcessInstanceByKey(processDefinitionKey);
		System.out.println("流程启动成功:" + processInstance.getId() + "   " + processInstance.getProcessDefinitionId() + "  "
				+ processInstance.getProcessInstanceId());

	}

	/**
	 * 查询我的个人任务act_ru_task
	 */
	@Test
	public void queryMyTask() {
		TaskService taskService = this.processEngine.getTaskService();
		String assignee = "李四";
		List<Task> list = taskService.createTaskQuery()
				// 条件
				.taskAssignee(assignee)// 根据任务办理人查询任务
				// 排序
				.orderByTaskCreateTime().desc()
				// 结果集
				.list();

		if (null != list && list.size() > 0) {
			for (Task task : list) {
				System.out.println("任务ID:" + task.getId());
				System.out.println("任务办理人:" + task.getAssignee());
				System.out.println("执行实例ID:" + task.getExecutionId());
				System.out.println("任务名称:" + task.getName());
				System.out.println("流程定义ID:" + task.getProcessDefinitionId());
				System.out.println("流程实例ID:" + task.getProcessInstanceId());
				System.out.println("任务创建时间:" + task.getCreateTime());
				System.out.println("####################");
			}
		}
	}

	/**
	 * 办理任务
	 */
	@Test
	public void completeTask() {
		TaskService taskService = this.processEngine.getTaskService();
		String taskId = "15003";
		// 根据任务ID去完成任务
		taskService.complete(taskId);
		// 根据任务ID去完成任务并指定流程变量
//		taskService.complete(taskId, variables);
		System.out.println("任务完成");
	}
	/**
	 * 办理任务并使用流程变量指定流程走向
	 */
	@Test
	public void completeTask2() {
		TaskService taskService = this.processEngine.getTaskService();
		String taskId = "12502";
		Map<String, Object> variables=new HashMap<>();
		variables.put("outcome", "重要");
		// 根据任务ID去完成任务并指定流程变量
		taskService.complete(taskId, variables);
		System.out.println("任务完成");
	}

	/**
	 * 判断流程是否结束 作用：更新业务表里面的状态
	 */
	@Test
	public void isComplete() {
		// 已知流程实例ID
		RuntimeService runtimeService = this.processEngine.getRuntimeService();
		String processInstanceId = "2501";
		ProcessInstance processInstance = runtimeService.createProcessInstanceQuery()
				.processInstanceId(processInstanceId).singleResult();
		if (null != processInstance) {
			System.out.println("流程未结束");
		} else {
			System.out.println("流程已结束");
		}

		// 已知任务ID 5002 [了解]
		// 根据任务ID查询任务实例对象
		/*
		 * TaskService taskService = this.processEngine.getTaskService(); String
		 * taskId="5002"; Task task =
		 * taskService.createTaskQuery().taskId(taskId).singleResult();
		 * //从任务实例里面取出流程实例ID String processInstanceId2 = task.getProcessInstanceId();
		 * //使用流程实例ID去流程实例表里面查询有没有数据 ProcessInstanceQuery processInstance2 =
		 * runtimeService.createProcessInstanceQuery().processInstanceId(
		 * processInstanceId2); if (null != processInstance2) {
		 * System.out.println("流程未结束"); } else { System.out.println("流程已结束"); }
		 */

	}

	/**
	 * 7，查询当前的流程实例 act_ru_execution
	 * 
	 */
	@Test
	public void queryProcessInstance() {
		RuntimeService runtimeService = this.processEngine.getRuntimeService();
		List<ProcessInstance> list = runtimeService.createProcessInstanceQuery().list();
		if (null != list && list.size() > 0) {
			for (ProcessInstance pi : list) {
				System.out.println("执行实例ID:" + pi.getId());
				System.out.println("流程定义ID:" + pi.getProcessDefinitionId());
				System.out.println("流程实例ID:" + pi.getProcessInstanceId());
				System.out.println("########################");
			}
		}
	}

	/**
	 * 7，附加功能，查询历史任务（后面讲）act_hi_taskinst
	 */
	@Test
	public void queryHistoryTask() {
		HistoryService historyService = this.processEngine.getHistoryService();
		List<HistoricTaskInstance> list = historyService.createHistoricTaskInstanceQuery().list();
		if (null != list && list.size() > 0) {
			for (HistoricTaskInstance hi : list) {
				System.out.println("任务ID:" + hi.getId());
				System.out.println("任务办理人:" + hi.getAssignee());
				System.out.println("执行实例ID:" + hi.getExecutionId());
				System.out.println("任务名称:" + hi.getName());
				System.out.println("流程定义ID:" + hi.getProcessDefinitionId());
				System.out.println("流程实例ID:" + hi.getProcessInstanceId());
				System.out.println("任务创建时间:" + hi.getCreateTime());
				System.out.println("任务结束时间:" + hi.getEndTime());
				System.out.println("任务持续时间:" + hi.getDurationInMillis());
				System.out.println("####################");
			}
		}

	}

	/**
	 * 8，附加功能，查询历史流程实例（后面讲）
	 */
	@Test
	public void queryHistoryProcessInstance() {
		HistoryService historyService = this.processEngine.getHistoryService();
		List<HistoricProcessInstance> list = historyService.createHistoricProcessInstanceQuery().list();
		if (null != list && list.size() > 0) {
			for (HistoricProcessInstance hi : list) {
				System.out.println("执行实例ID:" + hi.getId());
				System.out.println("流程定义ID:" + hi.getProcessDefinitionId());
				System.out.println("流程启动时间:" + hi.getStartTime());
				System.out.println("########################");
			}
		}
	}

}
