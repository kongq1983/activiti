package com.sxt.i_parallelGateWay;

import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipInputStream;

import org.activiti.engine.ProcessEngine;
import org.activiti.engine.ProcessEngines;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.jupiter.api.Test;

/**
 * 并行网关
 * if else if  else if  else
 * @author LJH
 *
 */
public class TestParallelGateWay {

	private ProcessEngine processEngine = ProcessEngines.getDefaultProcessEngine();

	/**
	 * 部署流程使用zip
	 */
	@Test
	public void deployProcess() {
		// 得到流程部署的service
		RepositoryService repositoryService = this.processEngine.getRepositoryService();
		InputStream inputStream=this.getClass().getResourceAsStream("ParallelGateWay.zip");
		ZipInputStream zipInputStream=new ZipInputStream(inputStream);
		Deployment deploy = repositoryService.createDeployment().name("tao宝流程")
				.addZipInputStream(zipInputStream).deploy();
		System.out.println("部署成功:流程部署ID：" + deploy.getId());
	}

	/**
	 * 启动流程
	 */
	@Test
	public void startProcess() {
		RuntimeService runtimeService = this.processEngine.getRuntimeService();
		String processDefinitionKey = "myProcess";
		ProcessInstance processInstance = runtimeService.startProcessInstanceByKey(processDefinitionKey);
		System.out.println("流程启动成功:" + processInstance.getId() + "   " + processInstance.getProcessDefinitionId() + "  "
				+ processInstance.getProcessInstanceId());

	}

	/**
	 * 查询我的个人任务act_ru_task
	 */
	@Test
	public void queryMyTask() {
		TaskService taskService = this.processEngine.getTaskService();
//		String assignee = "张三";
		String assignee = "商家";
//		String assignee = "买家";
		List<Task> list = taskService.createTaskQuery()
				// 条件
				.taskAssignee(assignee)// 根据任务办理人查询任务
				// 排序
				.orderByTaskCreateTime().desc()
				// 结果集
				.list();

		if (null != list && list.size() > 0) {
			for (Task task : list) {
				System.out.println("任务ID:" + task.getId());
				System.out.println("任务办理人:" + task.getAssignee());
				System.out.println("执行实例ID:" + task.getExecutionId());
				System.out.println("任务名称:" + task.getName());
				System.out.println("流程定义ID:" + task.getProcessDefinitionId());
				System.out.println("流程实例ID:" + task.getProcessInstanceId());
				System.out.println("任务创建时间:" + task.getCreateTime());
				System.out.println("####################");
			}
		}
	}

	/**
	 * 办理任务
	 */
	@Test
	public void completeTask() {
		TaskService taskService = this.processEngine.getTaskService();
		String taskId = "10002";
		// 根据任务ID去完成任务
		taskService.complete(taskId);
		// 根据任务ID去完成任务并指定流程变量
		System.out.println("任务完成");
	}
}
