package com.sxt.j_receiveTask;

import java.io.InputStream;
import java.util.zip.ZipInputStream;

import org.activiti.engine.ProcessEngine;
import org.activiti.engine.ProcessEngines;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.runtime.Execution;
import org.activiti.engine.runtime.ProcessInstance;
import org.junit.jupiter.api.Test;

/**
 * 接收活动。
 * 
 * @author LJH
 *
 */
public class TestReceiveTask {

	private ProcessEngine processEngine = ProcessEngines.getDefaultProcessEngine();

	/**
	 * 部署流程使用zip
	 */
	@Test
	public void deployProcess() {
		// 得到流程部署的service
		RepositoryService repositoryService = this.processEngine.getRepositoryService();
		InputStream inputStream = this.getClass().getResourceAsStream("Desktop.zip");
		ZipInputStream zipInputStream = new ZipInputStream(inputStream);
		Deployment deploy = repositoryService.createDeployment().name("汇总流程").addZipInputStream(zipInputStream)
				.deploy();
		System.out.println("部署成功:流程部署ID：" + deploy.getId());
	}

	/**
	 * 启动流程
	 */
	@Test
	public void startProcess() {
		RuntimeService runtimeService = this.processEngine.getRuntimeService();
		String processDefinitionKey = "myProcess";
		ProcessInstance processInstance = runtimeService.startProcessInstanceByKey(processDefinitionKey);
		System.out.println("流程启动成功:" + processInstance.getId() + "   " + processInstance.getProcessDefinitionId() + "  "
				+ processInstance.getProcessInstanceId());
	}

	@Test
	public void executionTask() {
		RuntimeService runtimeService = this.processEngine.getRuntimeService();
		String processInstanceId = "2501";
		/** 查询执行对象ID */
		Execution execution1 = runtimeService//
				.createExecutionQuery()// 创建执行对象查询
				.processInstanceId(processInstanceId)// 使用流程实例ID查询
				.activityId("receivetask1")// 当前活动的id，对应receiveTask.bpmn文件中的活动节点id的属性值
				.singleResult();
		System.out.println("执行实例ID:" + execution1.getId());
		System.out.println("流程实例ID:" + execution1.getProcessInstanceId());
		System.out.println("活动ID:" + execution1.getActivityId());

		/** 使用流程变量设置当日销售额，用来传递业务参数 */
		int value = 10000;// 应该是去查询数据库，进行汇总 ---耗时操作
		runtimeService.setVariable(execution1.getId(), "当前的销售额", value);
		/** 向后执行一步，如果流程处于等待状态，使得流程继续执行 */
		runtimeService.signal(execution1.getId());
	}

	/**
	 * 发短信
	 */
	@Test
	public void sendMessage() {
		RuntimeService runtimeService = this.processEngine.getRuntimeService();
		String executionId = "2501";
		/** 从流程变量中获取汇总当日销售额的值 */
		Integer value = (Integer) runtimeService//
				.getVariable(executionId, "当前的销售额");
		System.out.println(value);
		System.out.println("发送短信");
		Boolean flag = false;
		int num = 0;
		do {
			flag = send();
			num++;
			if (num == 10) {
				System.out.println("尝试10次发送。全部失败，已终止发送");
				break;
			}
		} while (!flag);

		/** 向后执行一步，如果流程处于等待状态，使得流程继续执行 */
		runtimeService.signal(executionId);
		System.out.println("流程执行完成");

	}

	private Boolean send() {
		System.out.println("发送成功");
		return true;
	}

	@Test
	public void doTask() {
		RuntimeService runtimeService = this.processEngine.getRuntimeService();
		String processDefinitionKey = "myProcess";
		ProcessInstance processInstance = runtimeService.startProcessInstanceByKey(processDefinitionKey);
		System.out.println("流程启动成功:" + processInstance.getId() + "   " + processInstance.getProcessDefinitionId() + "  "
				+ processInstance.getProcessInstanceId());
		/** 使用流程变量设置当日销售额，用来传递业务参数 */
		int value = 0;// 应该是去查询数据库，进行汇总 ---耗时操作
		int tryNum=0;
		while (true) {
			tryNum++;
			try {
				value = this.hzxx();
				break;
			} catch (Exception e) {
				e.printStackTrace();
				if(tryNum==10) {
					System.out.println("尝试10次汇总。全部失败，已终止汇总");
					break;
				}
			}
		}
		runtimeService.setVariable(processInstance.getId(), "当前的销售额", value);
		/** 向后执行一步，如果流程处于等待状态，使得流程继续执行 */
		runtimeService.signal(processInstance.getId());
		
		/** 从流程变量中获取汇总当日销售额的值 */
		Integer saleMoney = (Integer) runtimeService//
				.getVariable(processInstance.getId(), "当前的销售额");
		System.out.println(saleMoney);
		System.out.println("发送短信");
		Boolean flag = false;
		int num = 0;
		do {
			flag = send();
			num++;
			if (num == 10) {
				System.out.println("尝试10次发送。全部失败，已终止发送");
				break;
			}
		} while (!flag);

		/** 向后执行一步，如果流程处于等待状态，使得流程继续执行 */
		runtimeService.signal(processInstance.getId());
		System.out.println("流程执行完成");
	}

	public Integer hzxx() {
		// 查询数据库
		System.out.println("数据汇总中....");
		try {
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("数据汇总完成");
		return 10000;
	}

}
