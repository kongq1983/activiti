package com.sxt.k_personTask;

import org.activiti.engine.delegate.DelegateTask;
import org.activiti.engine.delegate.TaskListener;

/**
 * 监听器
 * @author LJH
 *
 */
public class TaskListenerImpl implements TaskListener{

	@Override
	public void notify(DelegateTask delegateTask) {
		System.out.println("进来了");
		String assignee="王五";
		//使用解耦的方式得到HttpServletRequest  再从request里面得到sesison
		//从session里面得到用户
		//根据用户的mgr查询用户的上级领导  
		//指定办理人
		delegateTask.setAssignee(assignee);
	}

}
