package com.sxt.k_personTask;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.ProcessEngine;
import org.activiti.engine.ProcessEngines;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.task.Task;
import org.junit.jupiter.api.Test;

/**
 * 人个任务使用流程变量去设置
 * @author LJH
 *
 */
public class PersonTask01 {

	//得到流程引擎
	private ProcessEngine processEngine=ProcessEngines.getDefaultProcessEngine();
	
	@Test
	public void deployProcess() {
		//得到流程部署的service
		RepositoryService repositoryService = this.processEngine.getRepositoryService();
		Deployment deploy = repositoryService.createDeployment().name("请假流程001")
		.addClasspathResource("HelloWorld.bpmn")
		.addClasspathResource("HelloWorld.png")
		.deploy();
		System.out.println("部署成功:流程部署ID："+deploy.getId());
	}
	/**
	 * 启动流程并指定下一个任务的办理人
	 */
	@Test
	public void startProcess() {
		RuntimeService runtimeService = this.processEngine.getRuntimeService();
		String processDefinitionKey="HelloWorld";
		Map<String,Object> variables=new HashMap<>();
		variables.put("username", "张三");
		runtimeService.startProcessInstanceByKey(processDefinitionKey,variables);
		System.out.println("流程启动成功");
	}
	
	
	/**
	 * 查询任务
	 */
	@Test
	public void findTask() {
		TaskService taskService = this.processEngine.getTaskService();
		String assignee="李四";
		List<Task> list = taskService.createTaskQuery().taskAssignee(assignee).list();
		if(null!=list&&list.size()>0) {
			for (Task task : list) {
				System.out.println("任务ID:"+task.getId());
				System.out.println("流程实例ID:"+task.getProcessInstanceId());
				System.out.println("执行实例ID:"+task.getExecutionId());
				System.out.println("流程定义ID:"+task.getProcessDefinitionId());
				System.out.println("任务名称:"+task.getName());
				System.out.println("任务办理人:"+task.getAssignee());
				System.out.println("################################");
			}
		}
	}
	/**
	 * 办理任务
	 */
	@Test
	public void completeTask() {
		TaskService taskService = this.processEngine.getTaskService();
		String taskId="5002";
		taskService.complete(taskId);
		System.out.println("任务完成");
	}
}
