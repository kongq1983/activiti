package com.sxt.l_gorupTask;

import org.activiti.engine.delegate.DelegateTask;
import org.activiti.engine.delegate.TaskListener;

/**
 * 监听器
 * @author LJH
 *
 */
public class GroupTaskListenerImpl implements TaskListener{

	@Override
	public void notify(DelegateTask delegateTask) {
		System.out.println("进来了");
		delegateTask.addCandidateUser("小A");
		delegateTask.addCandidateUser("小B");
		delegateTask.addCandidateUser("小C");
		delegateTask.addCandidateUser("小D");
	}

}
