package com.sxt.l_gorupTask;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.ProcessEngine;
import org.activiti.engine.ProcessEngines;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.task.IdentityLink;
import org.activiti.engine.task.Task;
import org.junit.jupiter.api.Test;

/**
 * 组任务使用流程变量去设置
 * 
 * @author LJH
 *
 */
public class GroupTask01 {

	// 得到流程引擎
	private ProcessEngine processEngine = ProcessEngines.getDefaultProcessEngine();

	@Test
	public void deployProcess() {
		// 得到流程部署的service
		RepositoryService repositoryService = this.processEngine.getRepositoryService();
		Deployment deploy = repositoryService.createDeployment().name("请假流程001").addClasspathResource("HelloWorld.bpmn")
				.addClasspathResource("HelloWorld.png").deploy();
		System.out.println("部署成功:流程部署ID：" + deploy.getId());
	}

	/**
	 * 启动流程
	 */
	@Test
	public void startProcess() {
		RuntimeService runtimeService = this.processEngine.getRuntimeService();
		String processDefinitionKey = "HelloWorld";
		runtimeService.startProcessInstanceByKey(processDefinitionKey);
		System.out.println("流程启动成功");
	}

	/**
	 * 查询组任务
	 */
	@Test
	public void findGroupTask() {
		TaskService taskService = this.processEngine.getTaskService();
		String candidateUser = "小B";
		List<Task> list = taskService.createTaskQuery().taskCandidateUser(candidateUser).list();
		if (null != list && list.size() > 0) {
			for (Task task : list) {
				System.out.println("任务ID:" + task.getId());
				System.out.println("流程实例ID:" + task.getProcessInstanceId());
				System.out.println("执行实例ID:" + task.getExecutionId());
				System.out.println("流程定义ID:" + task.getProcessDefinitionId());
				System.out.println("任务名称:" + task.getName());
				System.out.println("任务办理人:" + task.getAssignee());
				System.out.println("################################");
			}
		}
	}

	/**
	 * 查询任务
	 */
	@Test
	public void findTask() {
		TaskService taskService = this.processEngine.getTaskService();
		String assignee = "小A";
		List<Task> list = taskService.createTaskQuery().taskAssignee(assignee).list();
		if (null != list && list.size() > 0) {
			for (Task task : list) {
				System.out.println("任务ID:" + task.getId());
				System.out.println("流程实例ID:" + task.getProcessInstanceId());
				System.out.println("执行实例ID:" + task.getExecutionId());
				System.out.println("流程定义ID:" + task.getProcessDefinitionId());
				System.out.println("任务名称:" + task.getName());
				System.out.println("任务办理人:" + task.getAssignee());
				System.out.println("################################");
			}
		}
	}

	/**
	 * 任务拾取
	 */
	@Test
	public void claim() {
		String taskId="2505";
		TaskService taskService = this.processEngine.getTaskService();
		taskService.claim(taskId, "小A");
		System.out.println("任务拾取成功");
	}
	/**
	 * 任务回退
	 */
	@Test
	public void claimBack() {
		String taskId="2504";
		TaskService taskService = this.processEngine.getTaskService();
		taskService.setAssignee(taskId, null);
		System.out.println("任务回退成功");
	}
	
    //5 查询组任务成员列表
    @Test
    public void findGroupUser(){
        String taskId = "2504";
        List<IdentityLink> list = processEngine.getTaskService()//
                        .getIdentityLinksForTask(taskId);
         //List<IdentityLink> list = processEngine.getRuntimeService()//
        //                .getIdentityLinksForProcessInstance(instanceId);
        for(IdentityLink identityLink:list ){
            System.out.println("userId="+identityLink.getUserId());
            System.out.println("taskId="+identityLink.getTaskId());
            System.out.println("piId="+identityLink.getProcessInstanceId());
            System.out.println("TYPE="+identityLink.getType());
            System.out.println("######################");
        }
    }
	
	
	

	/**
	 * 办理任务
	 */
	@Test
	public void completeTask() {
		TaskService taskService = this.processEngine.getTaskService();
		String taskId = "5002";
		taskService.complete(taskId);
		System.out.println("任务完成");
	}
	
	/**
	 * 添加组任务成功
	 */
	@Test
	public void addGroupUser() {
		String taskId="2504";
		TaskService taskService = this.processEngine.getTaskService();
		taskService.addCandidateUser(taskId, "小E");
		System.out.println("添加组成员成功");
	}
	
	/**
	 * 删除组任务成功
	 */
	@Test
	public void deleteGroupUser() {
		String taskId="2504";
		TaskService taskService = this.processEngine.getTaskService();
		taskService.deleteCandidateUser(taskId, "小E");
		System.out.println("添加组成员成功");
	}
}
